var menuActive = false;
var menu = $('.menu');
var burger = $('.menu-toggle');
initMenu();
function initMenu()
{
    if($('.menu').length)
    {
        var menu = $('.menu');
        if($('.menu-toggle').length)
        {
            burger.on('click', function()
            {
                if(menuActive)
                {
                    closeMenu();
                }
                else
                {
                    openMenu();

                    $(document).one('click', function cls(e)
                    {
                        if($(e.target).hasClass('menu_mm'))
                        {
                            $(document).one('click', cls);
                        }
                        else
                        {
                            closeMenu();
                        }
                    });
                }
            });
        }
    }
}

function openMenu()
{
    menu.addClass('active');
    menuActive = true;
}

function closeMenu()
{
    menu.removeClass('active');
    menuActive = false;
}

/*fixed header*/
$(window).scroll(function(){
    if ($(window).scrollTop() >= 40) {
        $('.header-container').addClass('fixed-header');
    }
    else {
        $('.header-container').removeClass('fixed-header');
    }
});

const auth = firebase.auth();
const db = firebase.firestore();

const loggedOuts = document.querySelectorAll(".logged-out")
const loggedIns = document.querySelectorAll(".logged-in")
const accountInfo = document.querySelector(".account-infos")
const creatBlog = document.querySelector(".admin")

const topBarUI = (user) => {
	if (user) {
        const html =`
        <div>Logged in as ${user.email}</div>
        `;
        accountInfo.innerHTML =html;

		loggedIns.forEach(item => item.style.display = "block");
        loggedOuts.forEach(item => item.style.display = "none");
        if (user.email && user.email.endsWith("@admin.com")) {
			creatBlog.style.display = "block"
		} else {
			creatBlog.style.display = "none"
		}
	} else {
        accountInfo.innerHTML = ''

		loggedIns.forEach(item => item.style.display = "none");
		loggedOuts.forEach(item => item.style.display = "block")
	}
}
auth.onAuthStateChanged(user => {
    if(user) {
        topBarUI(user)
    } else {
        topBarUI()
    }
})

//logout
const logout = document.querySelector("#logout")
logout.addEventListener("click", (e) => { 
    e.preventDefault();
    auth.signOut().then(() => {
        console.log("user sign out")
    })
})


const pathname = window.location.href.split('?');
const id = pathname[1].split('=')[1];
console.log(id)
db.collection('blogPost').doc(id).get()
.then((data)=>{       

        document.querySelector('#ga').innerHTML+=`
        <img src="${data.data().img}" alt="Image" class="img-fluid mb-5">
                <div class="post-meta">
                        <span class="author mr-2">${data.data().author}</span>&bullet;
                        <span class="mr-2">${data.data().time}</span> &bullet;
                        <span class="ml-2"><span class="fa fa-comments"></span> 3</span>
                </div>
            <h1 class="mb-4">${data.data().title}</h1>
            <a class="category mb-5" href="#">Food</a> <a class="category mb-5" href="#">${data.data().danhmuc}</a>
           
            <div class="post-content-body">
                <h4>${data.data().sub_content}</h4>
                <p>${data.data().content}</p>
            </div>

            
            <div class="pt-5">
              <p>Categories:  <a href="#">Food</a>, <a href="#">${data.data().danhmuc}</a></p>
            </div>
        `
    
}).catch((err)=>{
        console.log(err)
})