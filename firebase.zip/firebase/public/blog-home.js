var menuActive = false;
var menu = $('.menu');
var burger = $('.menu-toggle');
initMenu();
function initMenu()
{
    if($('.menu').length)
    {
        var menu = $('.menu');
        if($('.menu-toggle').length)
        {
            burger.on('click', function()
            {
                if(menuActive)
                {
                    closeMenu();
                }
                else
                {
                    openMenu();

                    $(document).one('click', function cls(e)
                    {
                        if($(e.target).hasClass('menu_mm'))
                        {
                            $(document).one('click', cls);
                        }
                        else
                        {
                            closeMenu();
                        }
                    });
                }
            });
        }
    }
}

function openMenu()
{
    menu.addClass('active');
    menuActive = true;
}

function closeMenu()
{
    menu.removeClass('active');
    menuActive = false;
}

/*fixed header*/
$(window).scroll(function(){
    if ($(window).scrollTop() >= 40) {
        $('.header-container').addClass('fixed-header');
    }
    else {
        $('.header-container').removeClass('fixed-header');
    }
});

const auth = firebase.auth();
const db = firebase.firestore();

const loggedOuts = document.querySelectorAll(".logged-out")
const loggedIns = document.querySelectorAll(".logged-in")
const accountInfo = document.querySelector(".account-infos")
const creatBlog = document.querySelector(".admin")

const topBarUI = (user) => {
	if (user) {
        const html =`
        <div>Logged in as ${user.email}</div>
        `;
        accountInfo.innerHTML =html;

		loggedIns.forEach(item => item.style.display = "block");
        loggedOuts.forEach(item => item.style.display = "none");
        if (user.email && user.email.endsWith("@admin.com")) {
			creatBlog.style.display = "block"
		} else {
			creatBlog.style.display = "none"
		}
	} else {
        accountInfo.innerHTML = ''

		loggedIns.forEach(item => item.style.display = "none");
		loggedOuts.forEach(item => item.style.display = "block")
	}
}
auth.onAuthStateChanged(user => {
    if(user) {
        topBarUI(user)
    } else {
        topBarUI()
    }
})

//logout
const logout = document.querySelector("#logout")
logout.addEventListener("click", (e) => { 
    e.preventDefault();
    auth.signOut().then(() => {
        console.log("user sign out")
    })
})

db.collection('blogPost').get()
.then((data)=>{
    data.forEach((element) => {        
        document.querySelector('#ga').innerHTML+=`
       
		
                <div class="blog-box col-md-6">
                  <a href="blog1.html?id=${element.id}" class="blog-entry element-animate" data-animate-effect="fadeIn">
                    <img src="${element.data().img}" alt="Image placeholder">
                    <div class="blog-content-body">
                      <div class="post-meta">
                        <span class="author mr-2">${element.data().author}</span>&bullet;
                        <span class="mr-2">${element.data().time}</span> &bullet;
                        <span class="ml-2"><span class="fa fa-comments"></span> 3</span>
                      </div>
                      <h2>${element.data().title}</h2>
                    </div>
                  </a>
                </div>
            
        `
    });
    
}).catch((err)=>{
    console.log(err)
})

db.collection('blogPost').get()
.then((dt)=>{
    dt.forEach((element) => {        
        document.querySelector('#boxer').innerHTML+=`
       
		
        <li>
        <a href="">
            <img src="${element.data().img}" alt="Image placeholder" class="mr-4">
            <div class="text">
            <h4>${element.data().title}</h4>
            <div class="post-meta">
                <span class="mr-2">${element.data().time}</span>
            </div>
            </div>
        </a>
        </li>
        <li>
            
        `
    });
    
}).catch((err)=>{
    console.log(err)
})