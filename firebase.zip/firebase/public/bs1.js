
const enroll = document.getElementById("dktv")

auth.onAuthStateChanged(user => {
    enroll.addEventListener("click", (e) => {
    e.preventDefault()
    if(user) {
    
            $('#exampleModalCenter').modal('show');
            $('#exampleModal').modal('hide');
            const formtuvan = document.querySelector("#formtuvan")
            formtuvan.addEventListener("click", (eve) => {
                eve.preventDefault()
                db.collection("tuVan")
                .add({
                    name: formtuvan["hoten"].value,
                    school: formtuvan["truong"].value,
                    birthday: formtuvan["bd"].value,
                    text: formtuvan["box"].value
                    }).then (() => {
                        formtuvan.reset()
                        window.location.href = "thankyou.html"
                    })
            })
        } else {
            $('#exampleModal').modal('show');
            $('#exampleModalCenter').modal('hide');
        }
    })
})