var db = firebase.firestore();
var storage = firebase.storage();

const fileButton = document.getElementById("fileButton")
const uploader = document.getElementById("uploader")

var blog = document.querySelector('#nhap');

fileButton.addEventListener('change', (e) => {
    imageFile= e.target.files[0]
})
blog.addEventListener('submit',(e) => { 
    e.preventDefault();
    let filename = imageFile.name;
    let storageRef = storage.ref("ImagesBlog/" + filename)
    let uploadTask = storageRef.put(imageFile);
    uploadTask.on('state_changed', function(snapshot) {
        let progress = snapshot.bytesTransferred / snapshot.totalBytes * 100
        uploader.value = progress
    }, function(error) {

    }, function () {
        storageRef.getDownloadURL().then(function(url) {
        db.collection('blogPost').add({
            title: blog['myInput2'].value,
            time: blog['myInput1'].value,
            author: blog['myInput5'].value,
            danhmuc: blog['danhmuc'].value,
            sub_content: blog['sub-title'].value,
            img: url,
            content: blog['myInput3'].value,      
            }).then(()=>{
                blog.reset();
            }) 
        })
    })
})



var menuActive = false;
var menu = $('.menu');
var burger = $('.menu-toggle');
initMenu();
function initMenu()
{
    if($('.menu').length)
    {
        var menu = $('.menu');
        if($('.menu-toggle').length)
        {
            burger.on('click', function()
            {
                if(menuActive)
                {
                    closeMenu();
                }
                else
                {
                    openMenu();

                    $(document).one('click', function cls(e)
                    {
                        if($(e.target).hasClass('menu_mm'))
                        {
                            $(document).one('click', cls);
                        }
                        else
                        {
                            closeMenu();
                        }
                    });
                }
            });
        }
    }
}

function openMenu()
{
    menu.addClass('active');
    menuActive = true;
}

function closeMenu()
{
    menu.removeClass('active');
    menuActive = false;
}

/*fixed header*/
$(window).scroll(function(){
    if ($(window).scrollTop() >= 40) {
        $('.header-container').addClass('fixed-header');
    }
    else {
        $('.header-container').removeClass('fixed-header');
    }
});

const auth = firebase.auth();

const loggedOuts = document.querySelectorAll(".logged-out")
const loggedIns = document.querySelectorAll(".logged-in")
const accountInfo = document.querySelector(".account-infos")
const creatBlog = document.querySelector(".admin")

const alertMessage = document.querySelector(".alert")
const topBarUI = (user) => {
	if (user) {
        const html =`
        <div>Logged in as ${user.email}</div>
        `;
        accountInfo.innerHTML =html;

		loggedIns.forEach(item => item.style.display = "block");
		loggedOuts.forEach(item => item.style.display = "none");

		if (user.email && user.email.endsWith("@admin.com")) {
			creatBlog.style.display = "block"
		} else {
			creatBlog.style.display = "none"
		}
	} else {
        accountInfo.innerHTML = ''

		loggedIns.forEach(item => item.style.display = "none");
		loggedOuts.forEach(item => item.style.display = "block")
	}
}
auth.onAuthStateChanged(user => {
    if(user) {
        topBarUI(user)
    } else {
        topBarUI()
    }
})